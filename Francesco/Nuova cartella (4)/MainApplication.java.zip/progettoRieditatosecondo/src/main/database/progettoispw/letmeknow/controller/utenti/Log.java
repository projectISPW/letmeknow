package progettoispw.letmeknow.controller.utenti;

public class Log {
    private String userID;
    private String type;
    public void setUserID(String input){
        userID=input;
    }
    public String getUserID(){
        return userID;
    }
}
