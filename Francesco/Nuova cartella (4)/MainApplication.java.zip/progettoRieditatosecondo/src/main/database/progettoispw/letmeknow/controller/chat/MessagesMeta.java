package progettoispw.letmeknow.controller.chat;

public class MessagesMeta {
    protected int DATETIME=1;
    protected int FROM=2;
    protected int TO=3;
    protected int TEXT=4;
}
