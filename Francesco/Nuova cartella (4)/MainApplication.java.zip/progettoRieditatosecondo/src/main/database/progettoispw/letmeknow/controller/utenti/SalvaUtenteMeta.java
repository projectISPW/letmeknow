package progettoispw.letmeknow.controller.utenti;

public class SalvaUtenteMeta {
    protected int USERID=1;
    protected int PASSWORD=2;
    protected int TYPE=3;
    protected int EMP=5;
    protected int HUM=6;
    protected int POS=7;
    protected int DES=8;
    protected int GOAL=9;
    protected int END=10;
    protected int TAG=11;
}
