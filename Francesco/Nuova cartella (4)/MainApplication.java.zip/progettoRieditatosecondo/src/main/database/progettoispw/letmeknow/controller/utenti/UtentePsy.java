package progettoispw.letmeknow.controller.utenti;

public class UtentePsy extends SalvaUtente{
    public UtentePsy(String who) {
        super(who);
    }
}
